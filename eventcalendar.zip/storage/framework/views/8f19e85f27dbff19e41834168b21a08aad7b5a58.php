<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    
    <div id="app" class="mt-5">
        <div class="container-fluid">
            <router-view></router-view>
        </div>
    </div>
    
    
    
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</body>
</html><?php /**PATH C:\laragon\www\eventcalendar\resources\views/welcome.blade.php ENDPATH**/ ?>